# 7brewmenuu.com

This repository contains the codebase for **7brewmenuu.com**, a simple static HTML site providing updated information on 7 Brew coffee menu prices.

## 📄 Contents
- `index.html`: Main page with article content on "7 Brew Menu Prices"
- `assets/style.css`: Basic styling
- `.gitignore`: For ignoring common temp files
- `README.md`: This file

## 🚀 Live Demo
You can host this using GitHub Pages or upload to your web host.

## 📌 License
This project is free for educational and demo use.
